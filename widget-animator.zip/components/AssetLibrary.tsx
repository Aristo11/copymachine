import React from 'react';
import { Asset } from '../types';
import { Plus, Trash2, Image, Upload } from 'lucide-react';

interface AssetLibraryProps {
  assets: Asset[];
  selectedAssetId: string | null;
  onSelect: (asset: Asset) => void;
  onUpload: () => void;
  onDelete: (id: string) => void;
}

export const AssetLibrary: React.FC<AssetLibraryProps> = ({ 
  assets, 
  selectedAssetId, 
  onSelect, 
  onUpload,
  onDelete
}) => {
  return (
    <div className="h-full flex flex-col bg-zinc-900 border-r border-zinc-800 w-[280px] shrink-0 z-20">
      {/* Header */}
      <div className="h-16 px-5 flex items-center justify-between border-b border-zinc-800/50">
        <h2 className="text-sm font-semibold text-zinc-100">Assets</h2>
        <button 
          onClick={onUpload}
          className="p-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-100 rounded-md transition-all hover:scale-105 active:scale-95"
          title="Upload New Asset"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1 custom-scrollbar">
        {assets.length === 0 && (
          <div className="mt-12 flex flex-col items-center justify-center text-zinc-600 gap-4 p-4 border-2 border-dashed border-zinc-800 rounded-xl mx-2">
            <div className="p-3 bg-zinc-800/50 rounded-full">
               <Upload className="w-5 h-5" />
            </div>
            <div className="text-center">
              <p className="text-xs font-medium text-zinc-400">No assets yet</p>
              <p className="text-[10px] mt-1">Upload an image to start</p>
            </div>
          </div>
        )}
        
        {assets.map(asset => (
          <div 
            key={asset.id}
            onClick={() => onSelect(asset)}
            className={`group relative flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-all duration-200 ${
              selectedAssetId === asset.id 
                ? 'bg-primary-500/10 ring-1 ring-primary-500/30' 
                : 'hover:bg-zinc-800/50'
            }`}
          >
            <div className={`w-10 h-10 rounded-md overflow-hidden bg-zinc-950 shrink-0 border ${selectedAssetId === asset.id ? 'border-primary-500/30' : 'border-zinc-800'}`}>
              <img src={asset.src} alt={asset.name} className="w-full h-full object-cover" />
            </div>
            
            <div className="min-w-0 flex-1">
              <p className={`text-xs font-medium truncate ${selectedAssetId === asset.id ? 'text-primary-400' : 'text-zinc-300 group-hover:text-white'}`}>
                {asset.name}
              </p>
              <p className="text-[10px] text-zinc-500 uppercase tracking-wider mt-0.5">
                {asset.type}
              </p>
            </div>
            
            <button 
              onClick={(e) => { e.stopPropagation(); onDelete(asset.id); }}
              className="opacity-0 group-hover:opacity-100 p-1.5 text-zinc-500 hover:text-red-400 hover:bg-red-400/10 rounded transition-all"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};