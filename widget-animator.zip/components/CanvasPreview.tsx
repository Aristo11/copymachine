
import React, { useRef, useEffect, useState } from 'react';
import { FXConfig, ImageDimensions } from '../types';
import { Download, Upload, ZoomIn, FileUp, Image as ImageIcon } from 'lucide-react';

interface CanvasPreviewProps {
  imageSrc: string | null;
  dimensions: ImageDimensions;
  config: FXConfig;
  onUpload: () => void;
  onFileSelect: (file: File) => void;
}

const CANVAS_PADDING = 100;

export const CanvasPreview: React.FC<CanvasPreviewProps> = ({ imageSrc, dimensions, config, onUpload, onFileSelect }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const visualTurbulenceRef = useRef<SVGFETurbulenceElement>(null);
  const requestRef = useRef<number>();
  
  const [isDragging, setIsDragging] = useState(false);

  const animateLightning = () => {
    if (config.enableLightning && config.lightningSpeed > 0 && config.lightningIntensity > 0) {
      const now = Date.now();
      if (now % Math.max(16, 100 - config.lightningSpeed * 1.8) < 16) {
          const newSeed = Math.floor(Math.random() * 1000);
          if (visualTurbulenceRef.current) {
            visualTurbulenceRef.current.setAttribute('seed', newSeed.toString());
          }
      }
    }
    requestRef.current = requestAnimationFrame(animateLightning);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animateLightning);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [config.lightningSpeed, config.lightningIntensity, config.enableLightning]);

  const handleExport = () => {
    if (!svgRef.current) return;
    
    // Clone the SVG node
    const svgClone = svgRef.current.cloneNode(true) as SVGSVGElement;
    
    // Calculate dynamic padding based on active effects to prevent clipping
    // We want the image as big as possible, but we need space for the glow to bleed out.
    let padding = 0;
    if (config.enableGlow) {
        // Allow space for ~1.5x the blur radius. 
        // We cap it at 30px to prevent the image from getting too small.
        padding = Math.min(config.glowIntensity * 1.5, 30);
    }
    
    // 1. Set viewBox with padding (centering the content)
    // -padding, -padding means (0,0) is shifted inside by 'padding' amount
    const vX = -padding;
    const vY = -padding;
    const vW = dimensions.width + (padding * 2);
    const vH = dimensions.height + (padding * 2);
    
    svgClone.setAttribute('viewBox', `${vX} ${vY} ${vW} ${vH}`);
    
    // 2. Enforce fixed output size as requested
    svgClone.setAttribute('width', '208');
    svgClone.setAttribute('height', '219');
    
    // 3. Ensure content scales to fit (contain) without distortion
    svgClone.setAttribute('preserveAspectRatio', 'xMidYMid meet');

    // 4. Reset the Root Group Position
    // Since the viewBox is centered around the image coordinates (shifted by padding),
    // we still position the root group at the center of the IMAGE dimensions.
    const rootGroup = svgClone.querySelector('#root-group');
    if (rootGroup) {
      rootGroup.setAttribute('transform', `translate(${dimensions.width / 2}, ${dimensions.height / 2})`);
    }
    
    // 5. Ensure overflow is visible in the exported file just in case
    svgClone.style.overflow = 'visible';

    const serializer = new XMLSerializer();
    const svgData = serializer.serializeToString(svgClone);
    const fullSvg = `<?xml version="1.0" standalone="no"?>\r\n${svgData}`;
    const blob = new Blob([fullSvg], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `lumina-fx-${Date.now()}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = (e: React.DragEvent) => { e.preventDefault(); setIsDragging(false); };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.[0]?.type.startsWith('image/')) {
      onFileSelect(e.dataTransfer.files[0]);
    }
  };

  const svgWidth = dimensions.width + (CANVAS_PADDING * 2);
  const svgHeight = dimensions.height + (CANVAS_PADDING * 2);

  // Calculate the center point of the editor canvas
  const centerX = CANVAS_PADDING + dimensions.width / 2;
  const centerY = CANVAS_PADDING + dimensions.height / 2;

  return (
    <div className="flex-1 flex flex-col h-full relative bg-zinc-950">
      
      {/* Hidden image for API analysis */}
      {imageSrc && <img id="source-image-hidden" src={imageSrc} className="hidden" alt="analysis-source" />}

      {/* Floating Toolbar */}
      <div className="absolute top-6 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 bg-zinc-900/80 backdrop-blur-md border border-zinc-800 rounded-full p-1.5 shadow-2xl ring-1 ring-black/20">
        <div className="px-3 py-1.5 flex items-center gap-2 border-r border-zinc-800">
            <ZoomIn className="w-4 h-4 text-zinc-500" />
            <span className="text-xs font-medium text-zinc-400">Preview</span>
        </div>
        
        <button 
            onClick={onUpload}
            className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-700/50 rounded-full transition-colors"
            title="Change Image"
        >
            <Upload className="w-4 h-4" />
        </button>

        {imageSrc && (
            <button 
                onClick={handleExport}
                className="flex items-center gap-2 bg-primary-600 hover:bg-primary-500 text-white text-xs font-bold px-4 py-2 rounded-full transition-all hover:shadow-lg hover:shadow-primary-500/25"
            >
                <Download className="w-3.5 h-3.5" />
                <span>Export 208x219</span>
            </button>
        )}
      </div>

      {/* Main Canvas Area */}
      <div className="flex-1 relative overflow-hidden">
        {/* Dot Grid Background */}
        <div className="absolute inset-0 pointer-events-none" 
             style={{ 
               backgroundImage: 'radial-gradient(#27272a 1px, transparent 1px)', 
               backgroundSize: '24px 24px',
               opacity: 0.5
             }}>
        </div>

        {/* Scrollable Viewport */}
        <div 
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className="absolute inset-0 overflow-auto custom-scrollbar flex"
        >
             <div className="min-w-full min-h-full flex items-center justify-center p-32">
                
                {!imageSrc ? (
                    <button 
                        onClick={onUpload}
                        className="group relative flex flex-col items-center justify-center w-96 h-64 rounded-3xl border-2 border-dashed border-zinc-800 hover:border-primary-500/50 hover:bg-zinc-900/30 transition-all duration-300 cursor-pointer"
                    >
                        <div className="w-16 h-16 bg-zinc-900 rounded-2xl flex items-center justify-center mb-4 shadow-xl group-hover:scale-110 transition-transform duration-300 border border-zinc-800">
                            <FileUp className="w-8 h-8 text-zinc-500 group-hover:text-primary-400 transition-colors" />
                        </div>
                        <h3 className="text-lg font-semibold text-zinc-300 group-hover:text-white transition-colors">Upload Image</h3>
                        <p className="text-sm text-zinc-500 mt-2">Drag & drop or click to browse</p>
                    </button>
                ) : (
                    <div className="relative" style={{ width: svgWidth, height: svgHeight }}>
                        <svg
                            ref={svgRef}
                            width={svgWidth}
                            height={svgHeight}
                            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                            xmlns="http://www.w3.org/2000/svg"
                            className="block relative z-10"
                            style={{ overflow: 'visible' }}
                        >
                        <defs>
                            <filter id="makeWhite">
                                <feColorMatrix type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1 0" />
                            </filter>
                            
                            <filter id="mask-feather">
                                <feGaussianBlur stdDeviation={config.masking.feather} />
                            </filter>

                            {/* Mask 1: Alpha Mask (Matches Image Shape) */}
                            <mask id="alphaMask" maskUnits="userSpaceOnUse">
                                <image href={imageSrc} width={dimensions.width} height={dimensions.height} filter="url(#makeWhite)" />
                            </mask>

                            {/* Mask 2: Region Mask (Rectangle Box) */}
                            <mask id="regionMask" maskUnits="userSpaceOnUse">
                                <rect width="100%" height="100%" fill={config.masking.enabled ? "black" : "white"} />
                                {config.masking.enabled && (
                                    <rect 
                                        x={`${config.masking.region.x}%`}
                                        y={`${config.masking.region.y}%`}
                                        width={`${config.masking.region.width}%`}
                                        height={`${config.masking.region.height}%`}
                                        fill="white"
                                        filter="url(#mask-feather)"
                                    />
                                )}
                            </mask>

                            <filter id="glow-filter" x="-50%" y="-50%" width="200%" height="200%">
                                <feGaussianBlur stdDeviation={config.glowIntensity} result="coloredBlur" />
                                <feFlood floodColor={config.glowColor} result="glowColor" />
                                <feComposite in="glowColor" in2="coloredBlur" operator="in" result="coloredBlur" />
                                <feMerge>
                                    <feMergeNode in="coloredBlur" />
                                </feMerge>
                            </filter>

                            <linearGradient id="sheenGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" stopColor={config.sheenColor} stopOpacity="0" />
                                <stop offset="40%" stopColor={config.sheenColor} stopOpacity="0" />
                                <stop offset="50%" stopColor={config.sheenColor} stopOpacity={config.sheenOpacity} />
                                <stop offset="60%" stopColor={config.sheenColor} stopOpacity="0" />
                                <stop offset="100%" stopColor={config.sheenColor} stopOpacity="0" />
                            </linearGradient>

                            <filter id="lightning-visual" x="-50%" y="-50%" width="200%" height="200%">
                                <feTurbulence 
                                    ref={visualTurbulenceRef} 
                                    type="turbulence" 
                                    baseFrequency={`${config.lightningFrequency} ${config.lightningFrequency * 5}`}
                                    numOctaves="2" 
                                    result="turb" 
                                    seed="0" 
                                />
                                <feColorMatrix 
                                    in="turb" 
                                    type="matrix" 
                                    values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 -9" 
                                    result="bolts" 
                                />
                                <feFlood floodColor={config.glowColor} result="boltColor" />
                                <feComposite in="boltColor" in2="bolts" operator="in" result="coloredBolts" />
                                <feGaussianBlur in="coloredBolts" stdDeviation="3" result="boltGlow" />
                                <feMerge>
                                    <feMergeNode in="boltGlow" />
                                    <feMergeNode in="coloredBolts" />
                                </feMerge>
                            </filter>
                        </defs>

                        <style>
                            {`
                            @keyframes breathe {
                                0%, 100% { transform: scale(1); opacity: 1; }
                                50% { transform: scale(${1 + config.breathingDepth}); opacity: 0.95; }
                            }
                            @keyframes sheenSlide {
                                0% { transform: translateX(-150%) skewX(-20deg); }
                                100% { transform: translateX(150%) skewX(-20deg); }
                            }
                            .animated-layer {
                                ${config.enableBreathing ? `animation: breathe ${config.breathingSpeed}s ease-in-out infinite;` : ''}
                            }
                            .sheen-layer {
                                animation: sheenSlide ${config.sheenSpeed}s linear infinite;
                                transform-box: fill-box;
                            }
                            `}
                        </style>

                        {/* ROOT GROUP */}
                        <g id="root-group" transform={`translate(${centerX}, ${centerY})`}>
                            
                            {/* ANIMATION GROUP (Breathing) */}
                            <g className="animated-layer">
                                
                                {/* OFFSET GROUP (Centering) */}
                                <g transform={`translate(${-dimensions.width / 2}, ${-dimensions.height / 2})`}>

                                    {/* Glow Layer */}
                                    {/* CRITICAL FIX: The filter must be on the GROUP, applied to the MASKED result.
                                        If we apply filter + mask on the image directly, the mask cuts the filter output.
                                        Structure: Group(Filter) -> Image(Masked) */}
                                    {config.enableGlow && (
                                        <g filter="url(#glow-filter)" opacity="0.9" style={{ mixBlendMode: 'plus-lighter' }}>
                                            <image
                                                href={imageSrc}
                                                width={dimensions.width}
                                                height={dimensions.height}
                                                mask="url(#regionMask)" 
                                            />
                                        </g>
                                    )}

                                    {/* Main Image (Always Full Visibility, unmasked by the effects region) */}
                                    <image
                                        href={imageSrc}
                                        width={dimensions.width}
                                        height={dimensions.height}
                                    />
                                    
                                    {/* Sheen Overlay */}
                                    {/* Sheen is restricted by BOTH the alpha mask (shape) AND the region mask (box) */}
                                    {config.enableSheen && config.sheenOpacity > 0 && (
                                        <g mask="url(#regionMask)">
                                            <g mask="url(#alphaMask)" style={{ mixBlendMode: 'plus-lighter' }}>
                                                <rect
                                                    x="-50%" y="-50%" width="200%" height="200%"
                                                    fill="url(#sheenGradient)"
                                                    className="sheen-layer"
                                                />
                                            </g>
                                        </g>
                                    )}

                                    {/* Lightning Overlay */}
                                    {config.enableLightning && config.lightningIntensity > 0 && (
                                        <g mask="url(#regionMask)">
                                            <rect
                                                width={dimensions.width}
                                                height={dimensions.height}
                                                filter="url(#lightning-visual)"
                                                mask="url(#alphaMask)"
                                                opacity={Math.min(1, config.lightningIntensity / 40)}
                                                style={{ mixBlendMode: 'screen', pointerEvents: 'none' }}
                                            />
                                        </g>
                                    )}
                                    
                                    {/* Mask Visualizer (Only in Editor) */}
                                    {config.masking.enabled && (
                                        <rect
                                            x={`${config.masking.region.x}%`}
                                            y={`${config.masking.region.y}%`}
                                            width={`${config.masking.region.width}%`}
                                            height={`${config.masking.region.height}%`}
                                            fill="none"
                                            stroke="#22d3ee"
                                            strokeWidth="1"
                                            strokeDasharray="4 4"
                                            opacity="0.5"
                                            pointerEvents="none"
                                        />
                                    )}
                                </g>
                            </g>
                        </g>
                        </svg>
                    </div>
                )}
            </div>
        </div>

        {isDragging && (
          <div className="absolute inset-0 z-50 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center animate-fade-in">
             <div className="bg-zinc-900 p-8 rounded-3xl border-2 border-primary-500 shadow-2xl flex flex-col items-center transform scale-110">
                <ImageIcon className="w-16 h-16 text-primary-400 mb-4 animate-bounce" />
                <h3 className="text-2xl font-bold text-white">Drop to Import</h3>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};
