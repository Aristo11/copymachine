import React, { useState, useRef, useEffect } from 'react';
import { FXConfig } from '../types';
import { Zap, Wind, Sun, Sparkles, Wand2, ScanEye, Target, Upload } from 'lucide-react';
import { detectSmartMask } from '../services/geminiService';

interface ControlPanelProps {
  config: FXConfig;
  onChange: (key: keyof FXConfig, value: any) => void;
  isAnalyzing: boolean;
  onAutoTune: () => void;
}

const ToggleSwitch: React.FC<{
  checked: boolean;
  onChange: (checked: boolean) => void;
}> = ({ checked, onChange }) => (
  <button
    onClick={() => onChange(!checked)}
    className={`w-9 h-5 rounded-full relative transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-zinc-900 focus:ring-primary-600 ${checked ? 'bg-primary-600' : 'bg-zinc-700'}`}
  >
    <div 
      className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-300 ${checked ? 'translate-x-4' : 'translate-x-0'}`} 
    />
  </button>
);

const SliderControl: React.FC<{
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (val: number) => void;
  disabled?: boolean;
}> = ({ label, value, min, max, step, onChange, disabled }) => (
  <div className={`group ${disabled ? 'opacity-40 pointer-events-none' : ''}`}>
    <div className="flex justify-between items-end mb-2">
      <label className="text-xs font-medium text-zinc-400 group-hover:text-zinc-300 transition-colors">
        {label}
      </label>
      <span className="text-xs font-mono text-zinc-500 bg-zinc-950 px-1.5 py-0.5 rounded border border-zinc-800 min-w-[3ch] text-center">
        {Math.round(value * 100) / 100}
      </span>
    </div>
    <div className="relative h-6 flex items-center">
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        disabled={disabled}
        className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-primary-500 hover:accent-primary-400 focus:outline-none focus:ring-0"
      />
    </div>
  </div>
);

const ControlGroup: React.FC<{
  title: string;
  icon: React.ElementType;
  enabled: boolean;
  onToggle: (v: boolean) => void;
  children: React.ReactNode;
}> = ({ title, icon: Icon, enabled, onToggle, children }) => (
  <div className={`rounded-xl border transition-all duration-300 ${enabled ? 'bg-zinc-900/50 border-zinc-800 shadow-lg' : 'bg-zinc-900/20 border-transparent opacity-70'}`}>
    <div className="p-4 flex items-center justify-between">
      <div className="flex items-center gap-2.5">
        <div className={`p-1.5 rounded-md ${enabled ? 'bg-primary-500/10 text-primary-400' : 'bg-zinc-800 text-zinc-500'}`}>
          <Icon className="w-4 h-4" />
        </div>
        <h3 className={`text-sm font-semibold ${enabled ? 'text-zinc-200' : 'text-zinc-500'}`}>{title}</h3>
      </div>
      <ToggleSwitch checked={enabled} onChange={onToggle} />
    </div>
    
    <div className={`px-4 pb-4 space-y-5 transition-all duration-300 origin-top ${enabled ? 'block opacity-100' : 'hidden opacity-0 h-0 overflow-hidden'}`}>
       {children}
    </div>
  </div>
);

export const ControlPanel: React.FC<ControlPanelProps> = ({ config, onChange, isAnalyzing, onAutoTune }) => {
  const [isDetecting, setIsDetecting] = useState(false);
  const [logoSrc, setLogoSrc] = useState<string | null>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  // Load persistent logo
  useEffect(() => {
    const savedLogo = localStorage.getItem('company_logo');
    if (savedLogo) {
        setLogoSrc(savedLogo);
    }
  }, []);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (ev) => {
            const result = ev.target?.result as string;
            setLogoSrc(result);
            localStorage.setItem('company_logo', result);
        };
        reader.readAsDataURL(file);
    }
  };

  const handleMaskDetection = async () => {
     if (!config.masking.prompt) return;
     setIsDetecting(true);
     
     const imgElement = document.querySelector('#source-image-hidden') as HTMLImageElement;
     if (imgElement) {
         try {
             const box = await detectSmartMask(imgElement.src, config.masking.prompt);
             onChange('masking', { ...config.masking, region: box, enabled: true });
         } catch (e) {
             alert("Detection failed. Try a different prompt.");
         }
     }
     setIsDetecting(false);
  };

  return (
    <div className="h-full bg-zinc-900 border-l border-zinc-800 flex flex-col w-[340px] shrink-0 z-20 shadow-xl">
      {/* Header */}
      <div className="h-16 px-6 border-b border-zinc-800/50 flex items-center justify-between shrink-0 bg-zinc-900 z-10">
        <h2 className="text-sm font-bold text-zinc-100">Configuration</h2>
        <button
          onClick={onAutoTune}
          disabled={isAnalyzing}
          className="group flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-semibold rounded-full transition-all shadow-lg hover:shadow-indigo-500/25 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isAnalyzing ? (
             <span className="animate-spin block w-3 h-3 border-2 border-white/30 border-t-white rounded-full" />
          ) : (
             <Wand2 className="w-3 h-3 group-hover:rotate-12 transition-transform" />
          )}
          <span>{isAnalyzing ? 'Analyzing...' : 'AI Auto-Tune'}</span>
        </button>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-4 pb-8">
        
        {/* Smart Masking */}
        <ControlGroup
            title="Effect Masking"
            icon={ScanEye}
            enabled={config.masking.enabled}
            onToggle={(v) => onChange('masking', { ...config.masking, enabled: v })}
        >
            <div className="space-y-3">
                <div className="flex gap-2">
                    <input 
                        type="text" 
                        placeholder="e.g. 'Sale Text' or 'Sword'"
                        value={config.masking.prompt}
                        onChange={(e) => onChange('masking', { ...config.masking, prompt: e.target.value })}
                        className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-primary-500"
                    />
                    <button 
                        onClick={handleMaskDetection}
                        disabled={isDetecting || !config.masking.prompt}
                        className="bg-zinc-800 hover:bg-primary-600 text-zinc-300 hover:text-white p-2 rounded-lg transition-colors disabled:opacity-50"
                        title="Detect Object"
                    >
                        {isDetecting ? <span className="animate-spin block w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full" /> : <Target className="w-3.5 h-3.5" />}
                    </button>
                </div>
                
                <div className="pt-2 border-t border-zinc-800/50 space-y-3">
                    <p className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Region Override</p>
                    <div className="grid grid-cols-2 gap-3">
                        <SliderControl 
                            label="X (%)" min={0} max={100} step={1} value={config.masking.region.x} 
                            onChange={(v) => onChange('masking', { ...config.masking, region: { ...config.masking.region, x: v }})} 
                        />
                        <SliderControl 
                            label="Y (%)" min={0} max={100} step={1} value={config.masking.region.y} 
                            onChange={(v) => onChange('masking', { ...config.masking, region: { ...config.masking.region, y: v }})} 
                        />
                        <SliderControl 
                            label="Width (%)" min={0} max={100} step={1} value={config.masking.region.width} 
                            onChange={(v) => onChange('masking', { ...config.masking, region: { ...config.masking.region, width: v }})} 
                        />
                        <SliderControl 
                            label="Height (%)" min={0} max={100} step={1} value={config.masking.region.height} 
                            onChange={(v) => onChange('masking', { ...config.masking, region: { ...config.masking.region, height: v }})} 
                        />
                    </div>
                    <SliderControl 
                        label="Feather (Edge Softness)" min={0} max={50} step={1} value={config.masking.feather} 
                        onChange={(v) => onChange('masking', { ...config.masking, feather: v })} 
                    />
                </div>
            </div>
        </ControlGroup>

        {/* Sheen Group */}
        <ControlGroup 
          title="Sheen" 
          icon={Sparkles} 
          enabled={config.enableSheen} 
          onToggle={(v) => onChange('enableSheen', v)}
        >
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-zinc-400">Color</label>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-zinc-500">{config.sheenColor}</span>
                <input
                  type="color"
                  value={config.sheenColor}
                  onChange={(e) => onChange('sheenColor', e.target.value)}
                  className="h-6 w-6 rounded-full overflow-hidden border border-zinc-700 cursor-pointer bg-transparent p-0"
                />
              </div>
            </div>
            <SliderControl
              label="Opacity"
              value={config.sheenOpacity}
              min={0}
              max={1}
              step={0.05}
              onChange={(v) => onChange('sheenOpacity', v)}
            />
            <SliderControl
              label="Duration (s)"
              value={config.sheenSpeed}
              min={0.5}
              max={10}
              step={0.1}
              onChange={(v) => onChange('sheenSpeed', v)}
            />
        </ControlGroup>

        {/* Glow Group */}
        <ControlGroup 
          title="Glow" 
          icon={Sun} 
          enabled={config.enableGlow} 
          onToggle={(v) => onChange('enableGlow', v)}
        >
             <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-zinc-400">Color</label>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-zinc-500">{config.glowColor}</span>
                <input
                  type="color"
                  value={config.glowColor}
                  onChange={(e) => onChange('glowColor', e.target.value)}
                  className="h-6 w-6 rounded-full overflow-hidden border border-zinc-700 cursor-pointer bg-transparent p-0"
                />
              </div>
            </div>
            <SliderControl
              label="Intensity (Blur Radius)"
              value={config.glowIntensity}
              min={0}
              max={50}
              step={1}
              onChange={(v) => onChange('glowIntensity', v)}
            />
        </ControlGroup>

        {/* Breathing Group */}
        <ControlGroup 
          title="Breathing" 
          icon={Wind} 
          enabled={config.enableBreathing} 
          onToggle={(v) => onChange('enableBreathing', v)}
        >
            <SliderControl
              label="Speed (Duration)"
              value={config.breathingSpeed}
              min={0.1}
              max={10}
              step={0.1}
              onChange={(v) => onChange('breathingSpeed', v)}
            />
            <SliderControl
              label="Depth (Scale)"
              value={config.breathingDepth}
              min={0}
              max={0.2}
              step={0.01}
              onChange={(v) => onChange('breathingDepth', v)}
            />
        </ControlGroup>

        {/* Lightning Group */}
        <ControlGroup 
          title="Lightning" 
          icon={Zap} 
          enabled={config.enableLightning} 
          onToggle={(v) => onChange('enableLightning', v)}
        >
            <SliderControl
              label="Intensity"
              value={config.lightningIntensity}
              min={0}
              max={100}
              step={1}
              onChange={(v) => onChange('lightningIntensity', v)}
            />
            <SliderControl
              label="Frequency (Detail)"
              value={config.lightningFrequency}
              min={0.001}
              max={0.1}
              step={0.001}
              onChange={(v) => onChange('lightningFrequency', v)}
            />
            <SliderControl
              label="Animation Speed"
              value={config.lightningSpeed}
              min={0}
              max={50}
              step={1}
              onChange={(v) => onChange('lightningSpeed', v)}
            />
        </ControlGroup>
      </div>
      
      {/* Footer */}
      <div className="px-6 py-4 border-t border-zinc-800 bg-zinc-900 shrink-0 flex items-center justify-between">
        <p className="text-[10px] text-zinc-500 font-medium scale-110 origin-left">Made By Raz Aris</p>
        <div 
            onClick={() => logoInputRef.current?.click()}
            className="group relative cursor-pointer"
            title="Click to change logo"
        >
            <input 
                ref={logoInputRef}
                type="file" 
                accept="image/*"
                className="hidden"
                onChange={handleLogoUpload}
            />
            {logoSrc ? (
                <div className="relative">
                    <img 
                        src={logoSrc} 
                        alt="Company Logo" 
                        className="h-8 w-auto max-w-[80px] object-contain opacity-70 group-hover:opacity-100 transition-opacity" 
                    />
                    {/* Hover overlay hint */}
                    <div className="absolute inset-0 flex items-center justify-center bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity rounded">
                         <Upload className="w-3 h-3 text-white" />
                    </div>
                </div>
            ) : (
                 <div className="flex items-center gap-2 px-2 py-1 rounded border border-zinc-800 bg-zinc-950 text-zinc-500 hover:text-zinc-300 hover:border-zinc-700 transition-all">
                    <Upload className="w-3 h-3" />
                    <span className="text-[10px] font-medium">Add Logo</span>
                 </div>
            )}
        </div>
      </div>
    </div>
  );
};