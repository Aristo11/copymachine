
import { GoogleGenAI, Type } from "@google/genai";
import { GeminiSuggestion, FXConfig } from "../types";

const CONFIG_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    reasoning: {
      type: Type.STRING,
      description: "Short explanation of why these effects fit the widget/UI element.",
    },
    config: {
      type: Type.OBJECT,
      properties: {
        enableGlow: { type: Type.BOOLEAN, description: "Should the object glow?" },
        glowColor: { type: Type.STRING, description: "Hex color code." },
        glowIntensity: { type: Type.NUMBER, description: "0-50." },
        
        enableBreathing: { type: Type.BOOLEAN, description: "Should the object pulse/breathe?" },
        breathingSpeed: { type: Type.NUMBER, description: "Duration in seconds." },
        breathingDepth: { type: Type.NUMBER, description: "0.01-0.2" },
        
        enableLightning: { type: Type.BOOLEAN, description: "Should the object have electric/lightning effects?" },
        lightningIntensity: { type: Type.NUMBER, description: "0-100." },
        lightningFrequency: { type: Type.NUMBER, description: "0.01-0.1" },
        lightningSpeed: { type: Type.NUMBER, description: "0-50" },
        
        enableSheen: { type: Type.BOOLEAN, description: "Should the object have a light sweep/sheen?" },
        sheenColor: { type: Type.STRING, description: "Hex color for the light sweep (usually white)." },
        sheenOpacity: { type: Type.NUMBER, description: "0-1. Intensity of the shine." },
        sheenSpeed: { type: Type.NUMBER, description: "Duration in seconds. Lower is faster." },
      }
    }
  }
};

const BOX_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    ymin: { type: Type.NUMBER },
    xmin: { type: Type.NUMBER },
    ymax: { type: Type.NUMBER },
    xmax: { type: Type.NUMBER }
  }
};

export const analyzeImageForFX = async (base64Image: string): Promise<GeminiSuggestion> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API Key not found in environment");
    }

    const ai = new GoogleGenAI({ apiKey });
    
    // Clean base64 string if it has header
    const cleanBase64 = base64Image.replace(/^data:image\/(png|jpg|jpeg|webp|svg\+xml);base64,/, "");

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/png', // Assuming PNG for simplicity
              data: cleanBase64
            }
          },
          {
            text: `Analyze this UI element / Game Widget and suggest animated SVG effects.
            
            Context:
            - "Call to Actions" generally need a "Sheen" enabled.
            - "Magic/Power" items generally need "Lightning" or "Glow" enabled.
            - "Idle" elements generally need "Breathing" enabled.
            
            Suggest boolean flags (enableGlow, enableSheen, etc.) and specific values for parameters.
            
            Return a JSON object matching the schema.`
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: CONFIG_SCHEMA,
        systemInstruction: "You are a UI Animation expert for Mobile Games and Casinos.",
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as GeminiSuggestion;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};

export const detectSmartMask = async (base64Image: string, prompt: string): Promise<{x: number, y: number, width: number, height: number}> => {
    try {
        const apiKey = process.env.API_KEY;
        if (!apiKey) throw new Error("API Key missing");

        const ai = new GoogleGenAI({ apiKey });
        const cleanBase64 = base64Image.replace(/^data:image\/(png|jpg|jpeg|webp|svg\+xml);base64,/, "");

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/png', data: cleanBase64 } },
                    { text: `Find the bounding box for the object described as "${prompt}". Return normalized coordinates (0-1).` }
                ]
            },
            config: {
                responseMimeType: "application/json",
                responseSchema: BOX_SCHEMA
            }
        });

        const text = response.text;
        if (!text) throw new Error("No response from Gemini");
        
        const box = JSON.parse(text);
        
        // Convert normalized coordinates to percentages (0-100)
        return {
            x: box.xmin * 100,
            y: box.ymin * 100,
            width: (box.xmax - box.xmin) * 100,
            height: (box.ymax - box.ymin) * 100
        };

    } catch (error) {
        console.error("Smart Mask Detection Error:", error);
        throw error;
    }
}